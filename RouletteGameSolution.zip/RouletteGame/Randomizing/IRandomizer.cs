namespace RouletteGame.Randomizing
{
    public interface IRandomizer
    {
        uint Next();
    }
}